module.exports = {
  ...require('.prisma/client/react-native'),
}
